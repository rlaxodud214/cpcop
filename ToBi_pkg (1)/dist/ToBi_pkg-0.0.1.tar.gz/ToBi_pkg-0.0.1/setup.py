import setuptools

setuptools.setup(
    name="ToBi_pkg",
    version="0.0.1",
    author="KPU_ToBi",
    author_email="golapaduck29@naver.com",
    description="A package for KPU_ToBi",
    url="https://github.com/golapaduck",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3.8",
    ],
)