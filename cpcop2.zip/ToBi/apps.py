from django.apps import AppConfig


class TobiConfig(AppConfig):
    name = 'ToBi'
